# PostGIS 数据源管理：代码与实现过程技术文档

> 适用版本：当前 `main` 分支（2026-11）
> 范围：`gisserver` 核心库、`mapserver/services/map-api` 引擎、`manager/backend` 管理后端与 `manager/ui` 前端中与 **PostGIS 数据源** 相关的全部代码路径。
> 阅读提示：文中 DSN 示例一律脱敏（`postgres://user:***@host:5432/gis`）；行号以当前提交为准，函数名与文件路径是稳定锚点。

---

## 目录

1. [文档目的与范围](#1-文档目的与范围)
2. [总体架构与调用关系](#2-总体架构与调用关系)
3. [配置与数据模型](#3-配置与数据模型)
4. [启动过程：从配置到连接注册表](#4-启动过程从配置到连接注册表)
5. [连接池与数据库版本门控](#5-连接池与数据库版本门控)
6. [SQL 模板层](#6-sql-模板层)
7. [OGC Filter 下推](#7-ogc-filter-下推)
8. [源坐标系网格](#8-源坐标系网格)
9. [管理器侧完整业务流程](#9-管理器侧完整业务流程)
10. [引擎运行时服务路径](#10-引擎运行时服务路径)
11. [安全设计](#11-安全设计)
12. [已知限制与风险清单](#12-已知限制与风险清单)
13. [常见错误与排障](#13-常见错误与排障)
14. [代码索引](#14-代码索引)
15. [附录：请求示例与 SQL 速查](#15-附录请求示例与-sql-速查)

---

## 1. 文档目的与范围

本文回答四个问题：

1. PostGIS 数据源在本项目中**由哪些模块负责**，彼此如何调用；
2. 一条 PostGIS 图层从**登记、发现、发布到对外服务**的完整实现过程；
3. 每个环节的**关键数据结构、SQL 模板与配置项**；
4. 当前实现中的**安全边界、性能取舍与已知风险**。

不在本文范围内：PostgreSQL/PostGIS 的安装部署（见 `docs/postgresql16-postgis-*.md`）、普通文件型图层（GeoJSON/COG/PMTiles）的编码细节。

---

## 2. 总体架构与调用关系

### 2.1 三层职责

| 层 | crate / 目录 | 职责 | 是否直接连 PostGIS |
|---|---|---|---|
| 管理端 UI | `manager/ui`（Vue 3 + Vite） | Store/资源/发布表单、连接测试、SHP 导入、进度展示 | 否（全部经 manager 后端） |
| 管理后端 | `manager/backend`（Axum） | 控制面：工作区、Store、资源台账、发布编排、健康检查聚合 | 间接（通过 map-api 的 `/admin/*` 接口） |
| 地图引擎 | `mapserver/services/map-api`（Axum） | 数据面：MVT/WMS/WFS/OGC API；管理面：`/admin/*` 热更新与数据源探测 | 是（只读查询、SHP 导入写入） |
| 核心库 | `gisserver`（`pg_source`、`wms_common`） | 连接池、SQL 模板、Filter 转 SQL、源 SRID 网格 | 是（被 map-api 调用） |

依赖方向刻意保持单向：

```
manager/ui ──HTTP──> manager/backend ──HTTP──> map-api ──> gisserver::pg_source ──> PostgreSQL/PostGIS
                                              │
                                              └─ 共享库 sys_workspace / sys_store / sys_resource / sys_published_layer
```

> `gisserver` 是 crates.io 单包，`pg_source` 模块由 feature 控制；不配置任何 `source.type: postgis` 图层时，运行时**完全不会**建立 PG 连接池（`build_pg_registry` 返回 `Ok(None)`）。

### 2.2 端到端数据流

```
┌──────────── manager/ui ────────────┐
│ Store 表单（host/port/db/user/pwd） │
└──────────────┬─────────────────────┘
               │ /map/catalog/stores/connect  (preflight)
               ▼
┌──────────── manager/backend ───────┐        ┌──────────── map-api /admin/pg-test ────────────┐
│ validate_store → sys_store 落库     │───────>│ 临时 PgPool(size=1) → SELECT 1 → 丢弃          │
└──────────────┬─────────────────────┘        └────────────────────────────────────────────────┘
               │ /map/catalog/stores/{id}/discover
               ▼
┌──────────── manager/backend ───────┐        ┌──────────── map-api /admin/pg-tables ──────────┐
│ 生成 sys_resource 台账              │<───────│ geometry_columns + information_schema + ST_Extent│
└──────────────┬─────────────────────┘        └────────────────────────────────────────────────┘
               │ /map/catalog/publish
               ▼
┌──────────── manager/backend ───────┐        ┌──────────── map-api /admin/services ───────────┐
│ build_service_body → 同名检查       │───────>│ 写 <catalog.root>/postgis/<name>.xml → refresh   │
│ record_published → sys_published_layer       └──────────────┬─────────────────────────────────┘
└────────────────────────────────────┘                       │
                                                             ▼
                                      build_pg_registry（启动/热重载）
                                      ├─ validate
                                      ├─ 属性发现（information_schema / row description）
                                      ├─ GiST 索引检查
                                      ├─ bounds（ST_EstimatedExtent → ST_Extent）
                                      ├─ count（reltuples → count(*)）
                                      └─ PgRegistry::build（按 DSN 共享池）
                                                             │
                                                             ▼
                                      /mvt /wms /wfs /ogc/features/v1  →  ST_AsMVT / 要素查询
```

### 2.3 能力矩阵（`data_type_caps`）

`mapserver/services/map-api/src/admin/discover.rs` 中的 `data_type_caps("postgis_table")` 决定发现结果：

| data_type | 可发布 | 默认协议 | 说明 |
|---|---|---|---|
| `postgis_table` | 是 | `mvt,wms` | `service_types` 支持 `wms/wfs/mvt/oaf` |
| `pg_table` | 否 | 无 | 无 geometry 列的普通表，仅用于「数据查询服务」 |

代码位置：`admin/discover.rs:293`（`pg_table_entries`）。

> PostGIS 图层**不支持** WMTS/XYZ 栅格化缓存，但可通过发布时选择的网格在 `/mvt/{layer}/{tms}/...` 与 WMTS 元数据中按网格寻址（瓦片仍是动态查询）。见 §8、§10.1。

---

## 3. 配置与数据模型

### 3.1 `PgSourceDef` 字段

定义于 `gisserver/src/wms_common/pg_source_def.rs`。该结构体只依赖 serde，不依赖 tokio/连接池，因此可被 `Layer` 直接引用（`SourceKind::Postgis(PgSourceDef)`）。

| 字段 | 类型 | 默认 | 说明 |
|---|---|---|---|
| `dsn` | `String` | 必填 | PostgreSQL 连接串 |
| `schema` | `String` | `public` | 模式名 |
| `table` | `String` | 空 | 表/视图名；使用 `from` 时可空 |
| `geometry_column` | `String` | `geom` | 几何列 |
| `srid` | `i32` | 必填 | 表数据 SRID（如 4326 / 3857 / 4543） |
| `layer_id` | `Option<String>` | 图层名 | MVT 内部 layer 名 |
| `id_column` | `Option<String>` | 无 | MVT feature id、WFS/OGC API 的 id |
| `properties` | `Vec<String>` | 空=启动发现 | 输出属性列 |
| `minzoom` / `maxzoom` | `Option<u8>` | 无 | 元数据与瓦片范围提示 |
| `extent` | `Option<u32>` | 4096 | MVT 坐标空间 |
| `buffer` | `Option<u32>` | 64 | 瓦片单位缓冲 |
| `clip_geom` | `Option<bool>` | true | 是否按瓦片包络裁剪 |
| `limit` | `Option<u32>` | 无 | 单瓦片/单次 GetMap 要素上限 |
| `bounds` | `Option<[f64;4]>` | 启动探测 | EPSG:4326 范围 |
| `feature_count` | `Option<u64>` | 启动探测 | `#[serde(skip)]`，仅运行时填充 |
| `from` | `Option<String>` | 无 | SQL/视图 FROM 表达式（管理员可信） |
| `simplify` | `Option<SimplifyOpts>` | 无 | 低缩放级按瓦片单位简化 |

`validate()`（`pg_source_def.rs:119`）在启动/热重载时执行，失败即中止：

- `table` 与 `from` 至少有一个；
- `from` 不能为空串、不能包含 `;`（防止配置笔误拼接第二条语句）;
- `simplify.tile_units` 必须是有限正数。

`pool_key()`（`pg_source_def.rs:158`）直接返回原始 DSN：**DSN 文本完全相同**的多个图层共享一个连接池。

### 3.2 图层 XML 示例（脱敏）

`<catalog.root>/postgis/*.xml` 中的典型定义（取自 `run-env/config/postgis/wuhua_buildings.xml`，DSN 已脱敏）：

```xml
<layer name="wuhua_buildings"
       title="五华区建筑（PostGIS 动态矢量瓦片，EPSG:4543）"
       src_crs="EPSG:4543">
  <source type="postgis"
          dsn="postgres://postgres:***@localhost:5434/gis"
          table="wuhua_buildings"
          srid="4543"
          geometry_column="geom"
          id_column="gid"
          maxzoom="22">
    <properties>
      <item>height</item>
    </properties>
    <simplify under_zoom="12" tile_units="2"/>
  </source>
  <grids>
    <item>WebMercatorQuad</item>
    <item>CGCS2000_3dCM102E</item>
    <item>CGCS2000_3dCM102E_zone34</item>
  </grids>
  <custom_grids>
    <item id="CGCS2000_3dCM102E" crs="EPSG:4543" tile_px="256">
      <origin><item>333633.10</item><item>6098259.65</item></origin>
      <extent>...</extent>
      <resolutions>...</resolutions>
    </item>
  </custom_grids>
</layer>
```

XML 经 `mapserver/services/map-api/src/xmlcfg.rs` 解析成 `Layer`；manager 发布时等价地构造 JSON 文档，再由 `xmlcfg::to_xml` 写盘。

### 3.3 catalog 两种后端

`mapserver/services/map-api/src/config.rs` 的 `CatalogOpts`：

```toml
[catalog]
root = "./config"
backend = "files"   # 或 "db"
dsn = "postgres://..."
```

| 后端 | 读 | 写 | 适用 |
|---|---|---|---|
| `files`（默认） | `<catalog.root>/postgis/*.xml` 等目录扫描 | `POST /admin/services` 写 XML | 单机、文件即真理源 |
| `db` | 共享库 `sys_published_layer.service_doc`（`db_catalog::load_catalog`） | `map-api catalog-import` CLI | 多引擎共享一套发布台账 |

`db_catalog.rs` 的读取条件（`db_catalog.rs:29`）：

```sql
SELECT layer_name, service_doc::text
FROM sys_published_layer
WHERE del_flag = 0 AND state = 'active' AND service_doc IS NOT NULL
ORDER BY layer_name
```

每条 `service_doc` 先做环境变量展开（`xmlcfg::expand_env`），抽出 `custom_grids`，再反序列化为 `Layer`；单条失败只告警跳过。

### 3.4 管理库表

`manager/backend/sql/map.sql`：

- `sys_workspace`：工作区（数据根目录）；
- `sys_store`（约 348 行）：Store 定义，PostGIS 类型使用 `pg_dsn`、`pg_schema`；
- `sys_resource`（约 370 行）：发现出的数据图层台账，`data_type`、`source`（`schema.table`）、`meta`（SRID/几何列等）；
- `sys_published_layer`（约 406 行）：发布台账，`layer_name`、`service_types`、`mapserver_kind`、`state`、`del_flag`、`service_doc`（仅 `catalog-import` 写入）。

`sys_store` 关键列：

| 列 | 说明 |
|---|---|
| `store_type` | `postgis` / 目录型 |
| `base_path` | 目录型 Store 的数据根 |
| `pg_dsn` | 明文连接串（见 §12 风险） |
| `pg_schema` | 默认模式，缺省 `public` |

---

## 4. 启动过程：从配置到连接注册表

入口：`mapserver/services/map-api/src/main.rs` → `AppState` 构建 → `build_pg_registry(&cfg)`（main.rs:215）。

`state.rs:139-345` 的 `build_pg_registry` 分八步：

### 4.1 筛选 PostGIS 图层

```rust
let sources: Vec<(String, PgSourceDef)> = config.layers.iter()
    .filter_map(|l| match &l.source {
        SourceKind::Postgis(def) => Some((l.name.clone(), def.clone())),
        _ => None,
    })
    .collect();
if sources.is_empty() { /* PG support disabled */ return Ok(None); }
```

### 4.2 配置校验

每个 `def.validate()`；失败返回 `anyhow::Error`，由 `main` 直接终止启动——配置错误属于部署期错误，不应留到每请求再报。

### 4.3 属性发现

当 `properties` 为空时：

- 普通表：`discover_columns(pool, schema, table, geom_col)` 查询 `information_schema.columns`，排除几何列；
- SQL/视图（`from` 非空）：`discover_from_fields(pool, from, geom_col)`，执行 `SELECT * FROM <from> LIMIT 0`，从 row description 取列名与类型。

发现失败只告警，`properties` 保持空（结果是不输出属性，但瓦片几何仍可服务）。

### 4.4 GiST 索引检查

仅表源（`from.is_none()`）执行 `gist_index_sql(&def)`；计数为 0 时打印警告：

```
no GiST index on the geometry column; tile/feature queries will sequential-scan
```

启动阶段一次性提示，避免把问题留到 p99 延迟。

### 4.5 范围（bounds）探测

优先级：

1. 配置里显式 `bounds`；
2. `ST_EstimatedExtent`（读 planner 统计，快，可能为 NULL）；
3. `ST_Extent`（精确全表扫描，慢）。

SQL 层函数：`bounds_sql_estimated` / `bounds_sql`（`pg_source/sql.rs`）。结果统一转换为 EPSG:4326 的 `[minx,miny,maxx,maxy]`。

### 4.6 要素计数

1. 表源先读 `pg_class.reltuples`（`count_sql_estimated`）；
2. 估计值无效时执行精确 `count(*)`（`count_all_sql`）；
3. SQL/视图源直接精确计数。

计数用于 TileJSON、OGC API `numberMatched` 的初始元数据。

### 4.7 建立共享池

`PgRegistry::build(filled, PG_POOL_MAX)`（`gisserver/src/pg_source/mod.rs`）：

```rust
pub async fn build(sources: Vec<(String, PgSourceDef)>, max_size: usize)
    -> Result<Option<Self>, PgPoolError>
```

- 按 `def.pool_key()`（即 DSN）分组；
- 每组创建一个 `PgPool::new(dsn, max_size)`；
- 返回 `None` 表示没有 PostGIS 图层。

`PG_POOL_MAX = 8`（`state.rs:23`）。

### 4.8 注册表就位

`AppState.pg: RwLock<Option<Arc<PgRegistry>>>`（`state.rs:124`）。读路径通过 `pg_registry()`（`state.rs:637`）拿快照。

热重载 `/admin/reload`（`state.rs` 的 `refresh_catalog`）策略：

- 复用已有池：若现有注册表覆盖所有仍在服役的 PostGIS 图层，直接沿用；
- 否则用保留下来的图层配置重建注册表；
- 之后清空图层索引等缓存（`purge_caches(CacheScope::All)`）。

```rust
let pg = match self.pg_registry() {
    Some(r) if kept_postgis.iter().all(|n| r.find(n).is_some()) => Some(r),
    _ => {
        let mut pg_cfg = cfg.clone();
        pg_cfg.layers.retain(|l| served.iter().any(|s| s.name() == l.name));
        build_pg_registry(&pg_cfg).await?
    }
};
```

> 注意：连接池按 DSN 共享，热重载**不会**关闭从配置中移除的 DSN 对应的池，直到进程重启（`PgRegistry` 整体替换时旧 `Arc` 才可能释放）。

---

## 5. 连接池与数据库版本门控

`gisserver/src/pg_source/pool.rs`（281 行）。

### 5.1 构建

```rust
let config = dsn.parse::<tokio_postgres::Config>()?;
let mgr = Manager::from_config(config, NoTls, ManagerConfig {
    recycling_method: RecyclingMethod::Fast,
});
let pool = Pool::builder(mgr).max_size(max_size.max(1)).build()?;
```

- 使用 `deadpool-postgres`；
- **NoTls**：当前实现不支持 TLS（见 §12）；
- `pool_id` 由 host/port/db/user 组成，**不包含密码**，用于日志与错误信息。

### 5.2 版本预检 `PgPool::new`

| 检查 | 最低版本 | 结果 |
|---|---|---|
| PostgreSQL | 11.0 | 低于则 `PostgresTooOld` |
| PostGIS | 3.0 | 低于则 `PostgisTooOld`（`ST_TileEnvelope` 需要 3.0+） |
| `ST_TileEnvelope` margin 参数 | 3.1 | 低于则关闭 margin，改用加宽包络的谓词回退 |
| 推荐版本 | 3.5 | 低于仅告警（3.5 修复了部分缩放级缺几何的问题） |

版本查询：`SHOW server_version_num` 与 `postgis_full_version()`/`postgis_version()`（实现内 `probe_version`）。

### 5.3 `new_plain`

`PgPool::new_plain`（`pool.rs:106`）**跳过 PostGIS 探测**，只验证 PG 可达与版本，用于：

- `db` catalog 后端的元数据连接（库可能没有 PostGIS）；
- 共享台账读写。

> 注释明确：`new_plain` 建出的池**绝不能**用于瓦片 SQL，因为 `margin_capable=false`、PostGIS 版本为 0.0.0。

---

## 6. SQL 模板层

`gisserver/src/pg_source/sql.rs`（987 行，含大量单元测试）。

### 6.1 标识符与字面量安全

- `quote_ident`：双引号包裹并转义内部 `"`；
- `quote_literal`：单引号包裹并转义内部 `'`；
- 表名、模式名、几何列、属性列全部按标识符处理；
- `from` 表达式是唯一原样拼接的 SQL 片段，由 `validate` 保证不含 `;`，属于**管理员可信输入**（见 §11）。

### 6.2 瓦片 SQL 的三种坐标接口

| 接口 | 函数 | 几何处理 | 包络 |
|---|---|---|---|
| WebMercator 原生（EPSG:3857） | `tile_sql` | `ST_Transform(geom, 3857)` | `ST_TileEnvelope(z,x,y, margin => buffer/extent)` |
| 源 SRID 网格 | `tile_sql_projected` | 几何保持源 SRID | `ST_MakeEnvelope(minx,miny,maxx,maxy, srid)` |
| 源 SRID + 地理网格（可选） | `tile_sql_projected_env` | 同上 | 由 handler 计算包络后传入 |

核心形态（简化）：

```sql
WITH bounds AS (SELECT ST_TileEnvelope($1,$2,$3) AS geom),
mvtgeom AS (
  SELECT ST_AsMVTGeom(
           ST_Transform(t."geom", 3857),
           bounds.geom,
           $4,   -- extent
           $5,   -- buffer
           $6    -- clip_geom
         ) AS geom,
         t."height" AS "height",
         t."gid" AS "id"
  FROM "public"."wuhua_buildings" t, bounds
  WHERE t."geom" && ST_Transform(bounds.geom, 4543)   -- 索引可用的粗过滤
    AND ST_Intersects(t."geom", ST_Transform(bounds.geom, 4543))
  LIMIT $7
)
SELECT ST_AsMVT(mvtgeom.*, $8, $4, 'geom', $9) FROM mvtgeom;
```

要点：

1. `&&` 先走 GiST 索引，`ST_Intersects` 做精确过滤；
2. 包络按 `buffer/extent` 加宽（PostGIS ≥ 3.1 用 `margin`，否则显式扩大包络）；
3. `ST_AsMVT` 的 `feature_id_name` 使用 `id_column`（存在时）；
4. `limit` 直接进 SQL，防止单瓦片拉全表；
5. `simplify` 在低缩放级把几何包进 `ST_SimplifyPreserveTopology`，容差用**包络宽度表达式**计算，保证预编译语句可跨缩放级复用。

### 6.3 要素 / 计数 / 范围 / 按 id

| 函数 | 用途 | 关键点 |
|---|---|---|
| `feature_sql(def, bbox, filter, order_by, limit, offset)` | WMS/WFS/OGC items | bbox 用 `ST_MakeEnvelope`；filter/order 由上层校验后传入 |
| `count_sql(def, bbox, filter)` | `numberMatched` | 与 feature_sql 共享谓词，保证计数与结果一致 |
| `bounds_sql` / `bounds_sql_estimated` | 启动探测 | 输出 4326 范围 |
| `feature_by_id_sql` | OGC item | 按 `id_column` 或 `ctid` 定位 |
| `point_feature_sql` | GetFeatureInfo | 点附近容差查询 |
| `count_sql_estimated` / `count_all_sql` | 启动计数 | reltuples / count(*) |
| `gist_index_sql` | 启动检查 | 查 `pg_index` + `pg_class` |

`feature_sql` 的属性投影来自 `def.properties`（启动已发现或显式配置），几何统一 `ST_AsGeoJSON(ST_Transform(geom, 4326))`，属性名与值一并构造为 JSON。

### 6.4 发现 SQL

- `discover_columns`：`information_schema.columns`，排除几何列，按 ordinal 排序；
- `discover_from_fields`：`SELECT * FROM <from> LIMIT 0`，从列描述取字段；
- `discover_geometry_columns`：`geometry_columns` 视图（发现接口另有一套，见 §9.3）。

### 6.5 `sortby` 白名单

`parse_sortby(s, allowed)`：

- 支持 `prop`、`-prop`、逗号分隔多列；
- 只接受发布属性 + `id_column` 白名单内的列；
- 非法列返回 `Err`，handler 转 400（**失败即失败，绝不静默不排序**）。

### 6.6 单元测试

`sql.rs` 内测试覆盖：标识符转义、tile SQL 片段、margin 回退、投影接口、simplify 容差表达式、sortby 解析、filter 组合等。运行：

```bash
cargo test -p gisserver --features full
```

---

## 7. OGC Filter 下推

`gisserver/src/pg_source/filter.rs`（610 行）。

入口：

```rust
pub fn filter_to_where(xml: &str, geom_col: &str, srid: i32)
    -> Result<Option<String>, FilterError>
```

支持的操作：

| Filter 元素 | SQL 输出 |
|---|---|
| `PropertyIsEqualTo` | `"col" = $n` |
| `PropertyIsNotEqualTo` | `<>` |
| `PropertyIsLessThan` / `GreaterThan` | `<` / `>` |
| `<=` / `>=` | 对应 |
| `PropertyIsLike` | `LIKE`（`%`/`_` 通配，转义规则按 OGC） |
| `PropertyIsNull` | `IS NULL` |
| `PropertyIsBetween` | `BETWEEN` |
| `And` / `Or` / `Not` | 布尔组合 |
| `BBOX` | 包络相交 |
| GML 几何谓词（`Intersects`/`Within`/`Contains` 等） | `ST_Intersects` 等 + GML→WKT 构造 |

实现要点：

- 参数**全部**走 `$n` 占位符，不做字符串拼接；
- 列名先按 `properties`/`id_column` 白名单校验（由调用方传入几何列与 srid）；
- 不支持的算子返回 `Err`，handler 返回 400：**宁可报错，不可静默忽略过滤条件**；
- GML 坐标串解析后经 `ST_GeomFromText(..., srid)` 构造，SRID 与图层一致。

调用点：`handlers/ogcapi_features.rs`（`filter=<xml>` KVP）与 WFS `pg_get_feature`。

---

## 8. 源坐标系网格

`gisserver/src/pg_source/grid.rs`（226 行）。

当发布时选择的是「源坐标系网格」而不是 WebMercatorQuad 时：

- 地理坐标系（如 EPSG:4326）：
  - 顶层矩阵 `2 × 1`；
  - 第 `z` 级 `2^(z+1) × 2^z`；
  - 分辨率 `360 / (256 * 2^z)` 度/像素（默认 `tile_px=256`）。
- 投影坐标系（如 EPSG:4543）：
  - 采用全球 Web Mercator 的米制范围 `±20037508.342789244` 作为基准域；
  - 第 `z` 级分辨率 `2 * 20037508.342789244 / (256 * 2^z)` 米/像素；
  - 原点取左上角 `(minx, maxy)`。

函数：

| 函数 | 作用 |
|---|---|
| `tile_bounds(z,x,y)` | 返回该瓦片在源 CRS 下的包络 |
| `point_to_tile(x,y,z)` | 点 → 瓦片索引（GetFeatureInfo/调试） |
| `level(z)` | 该级矩阵宽高与分辨率 |

产生的包络直接传入 `tile_sql_projected` 的 `ST_MakeEnvelope(..., srid)`，因此**几何不需要投影变换**，适合 Gauss-Kruger 等大坐标投影；同时避免了 3857 在东西向 ±180° 外的失真。

自定义网格（天地图、ArcGIS Conf.xml、CGCS2000 分带）由 `custom_grids` 定义，经 `GridDef::to_tms(id)` 转成 `TileMatrixSet`，与上面的内置源 CRS 网格并存。

---

## 9. 管理器侧完整业务流程

所有列表/操作接口挂在 `/map/catalog/*`（`manager/backend/src/handlers/catalog.rs:78`）。

### 9.1 创建 PostGIS Store

前端 `manager/ui/src/views/map/catalog/store.vue` 收集：host、port、database、user、password、schema。默认端口为 **54321**（项目约定的本地 PostGIS 端口，见 `store_connect_preflight` 中的 `default_pg_port()`），schema 默认 `public`。

后端 `store_add` → `validate_store`（`catalog.rs:758`）：

```rust
if store_type == STORE_TYPE_POSTGIS {
    if !pg_dsn.is_empty()
        && !(pg_dsn.starts_with("postgres://") || pg_dsn.starts_with("postgresql://"))
    {
        return Err(AppError::Param("pgDsn 必须是 postgres:// 或 postgresql:// 连接串".into()));
    }
} else if base_path.is_empty() { ... }
```

- `name` 经 `validate_ident`（长度、字符集）；
- Store 类型必须在引擎 `capabilities` 返回的 `store_types` 内；
- DSN 为空是允许的：编辑时留空表示「保持原 DSN 不变」，因为响应只回显掩码串，无法往返。

响应 `store_json`（`catalog.rs:801`）**永不返回明文密码**：

```json
{
  "id": 3,
  "name": "gis-pg",
  "storeType": "postgis",
  "pgSchema": "public",
  "pgDsnConfigured": true,
  "pgDsnMasked": "postgres://postgres:***@localhost:54321/gis",
  "isPostgis": true
}
```

### 9.2 连接预检

两个入口：

- `POST /map/catalog/stores/connect`（未落库，表单阶段）；
- `POST /map/catalog/stores/{id}/connect`（已落库，读取库内 DSN）。

后端 `store_connect_preflight`（`catalog.rs:1105`）/ `store_connect`（`catalog.rs:1041`）把 DSN 与 schema 发给 map-api：

```json
POST /admin/pg-test
{ "dsn": "postgres://user:***@host:54321/gis" }
```

map-api `pg_test`（`admin/catalog_admin.rs:252`）：

1. `PgPool::new(dsn, 1)`（临时池，含版本预检）；
2. `SELECT 1`；
3. 返回 `{ok, detail}`，**不落盘、不建持久池、不进入注册表**。

> 预检会验证 PostGIS 版本；库存在但 PostGIS 过旧时会返回明确错误。

### 9.3 数据发现

`GET /map/catalog/stores/{id}/discover?schema=public` → map-api `POST /admin/pg-tables`。

`admin/discover.rs` 的 `pg_table_entries`（293 行）执行两类查询：

**（1）空间表**：`geometry_columns` + 每表 `ST_Extent`：

```sql
select f_table_schema, f_table_name, f_geometry_column,
       coord_dimension::text, srid, type
from geometry_columns
where ($1 = '' or f_table_schema = $1)
order by f_table_schema, f_table_name
limit $2;          -- MAX_ENTRIES = 2000
```

对每张表：

```sql
SELECT ST_Extent("geom")::text FROM "public"."wuhua_buildings";
```

输出条目：

```json
{
  "path": "public.wuhua_buildings",
  "name": "wuhua_buildings",
  "data_type": "postgis_table",
  "publishable": true,
  "needs_bbox": false,
  "bbox": [102.6, 25.0, 102.7, 25.1],
  "src_crs": "EPSG:4543",
  "service_types": ["wms","wfs","mvt","oaf"],
  "default_service_types": ["mvt","wms"],
  "meta": {
    "schema": "public",
    "table": "wuhua_buildings",
    "geometry_column": "geom",
    "coord_dimension": 3,
    "srid": 4543,
    "geometry_type": "POLYGON"
  }
}
```

**（2）普通表**：`information_schema.tables` 中排除系统模式（`pg_catalog`、`information_schema`、`topology`、`tiger`）与 PostGIS 元数据表（`spatial_ref_sys`、`geometry_columns` 等），且不在 `geometry_columns` 中的 BASE TABLE：

```json
{
  "path": "public.notice",
  "name": "notice",
  "data_type": "pg_table",
  "publishable": false,
  "bbox": null,
  "meta": { "schema": "public", "table": "notice" }
}
```

发现阶段**只读**，且使用 `PgPool::new(dsn, 1)` 临时池，结束后丢弃。

性能注意：每张空间表一次 `ST_Extent`；表多或数据大时发现可能较慢，上限 2000 条（`MAX_ENTRIES`）。

### 9.4 生成资源台账

manager 把发现条目写入 `sys_resource`：

- `data_type = postgis_table`；
- `source = "schema.table"`；
- `meta` 保存 `schema/table/geometry_column/srid/coord_dimension/geometry_type`；
- `publishable = 1`。

`resource_refresh`（`catalog.rs:1703`）可重新探测单条资源（重新读取 `ST_Extent` 等）；`resource_query`（`catalog.rs:1750`）**仅对 `pg_table` 开放**，用 `POST /admin/pg-query` 返回表数据。

### 9.5 普通表数据查询

`admin/catalog_admin.rs:298` 的 `pg_query`：

1. 校验 `dsn/schema/table`；
2. 表名与模式名按标识符引用；
3. 先 `SELECT * FROM "schema"."table" LIMIT 0` 取列；
4. 再 `SELECT * ... LIMIT min(user_limit, 1000)`；
5. 返回 `{columns, rows}`（二维数组）。

该路径不经过图层缓存，也不进入注册表，适合「数据查询服务」的只读浏览。

### 9.6 SHP 导入

入口：

- `POST /map/catalog/stores/{id}/import-shp`（同步）；
- `POST /map/catalog/stores/{id}/import-shp/stream`（SSE 进度）。

manager `store_import_shp`（`catalog.rs:1170`）把 `{dsn, schema, table, shp_path, encoding?, srid?}` 转给 map-api `pg_import_shp`/`pg_import_shp_stream`。

`mapserver/services/map-api/src/admin/pg_import.rs` 的 `run_import`（81 行起）：

1. **标识校验**：表名、模式名只能含安全字符；
2. **DBF 编码探测**：未指定 encoding 时尝试推断（`.cpg`/默认）；
3. **SRID 探测**：优先请求参数，其次 `.prj` 解析；
4. **重名保护**：目标表已存在返回 **409**，绝不覆盖；
5. 调用 **`shp2pgsql -s <srid> -I -D -W <encoding>`**：
   - `-I` 建 GiST 索引；
   - `-D` dump 模式（COPY 批量写入）；
   - `-W` 指定编码；
6. 通过 `COPY ... FROM STDIN`（`copy_in`）流式写入；
7. 每 1000 行上报一次进度（SSE `stage`/`rows`）。

导入完成后，用户需重新「发现」才能看到新表（发现结果不会自动刷新资源台账）。

### 9.7 发布

`manager/backend/src/handlers/catalog.rs:2381` 的 `publish`。

前置校验顺序：

1. `resource_id != 0`；
2. `layer_name` 合法（`validate_ident`，≤64）；
3. 资源 `publishable == 1`，否则带 `reason` 拒绝；
4. 服务类型由 `cap.resolve_service_types(&form.service_types)` 校验；
5. **3D 豁免**：`3dtiles`/`terrain` 跳过 CRS/bbox/网格校验；PostGIS **必须**有 CRS；
6. `validate_crs` + `normalize_bbox`；
7. `crs_suspicious`：CRS 与坐标范围明显不匹配时**拒绝发布**（防止局部坐标/错 CRS 上线）；
8. `resolve_publish_grid`：按 `form.grid_mode` / `form.grid` / ArcGIS Conf.xml 决定网格；
9. `build_service_body`（`catalog.rs:1922`）构造引擎请求体；
10. `ensure_name_free`：`sys_published_layer` 中同名且 `del_flag=0 AND state<>'deleted'` 时拒绝（避免覆盖他人配置；回收站同名可复用）；
11. `POST /admin/services`；
12. 引擎返回 `served != true` 时带 `skip_reason` 报错；
13. `record_published` 写台账。

PostGIS 的请求体（`build_service_body` 的 `kind == "postgis"` 分支）：

```json
{
  "kind": "postgis",
  "name": "wuhua_buildings",
  "title": "五华区建筑",
  "src_crs": "EPSG:4543",
  "extent": [102.6, 25.0, 102.7, 25.1],
  "source": {
    "type": "postgis",
    "dsn": "postgres://user:***@host:54321/gis",
    "schema": "public",
    "table": "wuhua_buildings",
    "geometry_column": "geom",
    "srid": 4543
  },
  "grids": ["WebMercatorQuad", "CGCS2000_3dCM102E"],
  "custom_grids": { "CGCS2000_3dCM102E": { "...": "..." } }
}
```

字段来源：

- `dsn`：Store 的 `pg_dsn`（明文经内网传给引擎）；
- `schema/table`：资源的 `source`（`schema.table`）拆分；
- `geometry_column`：`meta.geometry_column`，缺省 `geom`；
- `srid`：`meta.srid`，缺失时从 `src_crs` 的 `EPSG:<n>` 解析，仍缺失则报「请重新发现」。

引擎 `catalog_admin::create`（`admin/catalog_admin.rs:119`）收到后：

1. 校验 `name`、`kind`（`KINDS` 含 `postgis`）、`source.type` 与 `kind` 一致；
2. **data_root 约束**：`source.path`（PostGIS 为 `dsn`，不按本地路径校验）——对象存储 URI 不做本地路径检查；
3. 写 `<catalog.root>/postgis/<name>.xml`；
4. `state.refresh_catalog(true)` 热重载（重建服务集与注册表）；
5. 返回 `{name, kind, served, skip_reason, report}`。

`record_published`（`catalog.rs:2324`）写 `sys_published_layer`：`layer_name`、`title`、`src_crs`、`bbox`、`service_types`、`mapserver_kind`、`grid`、`remark` 等；**不写 `service_doc`**。

### 9.8 已发布服务生命周期

| 接口 | 行为 |
|---|---|
| `GET /map/catalog/published` | 列表（含引擎侧健康/用量，`published_json`） |
| `PUT /map/catalog/published/{id}` | 修改发布信息（标题、CRS、bbox、网格等），必要时重新 `POST /admin/services` |
| `PUT /map/catalog/published/{id}/state` | 停用/恢复/删除：同步 `sys_published_layer.state/del_flag` 与引擎 `PUT /admin/services/{kind}/{name}/state` |
| `GET /map/catalog/published/{id}/endpoints` | 生成对外 URL（MVT/WMS/WFS/OGC API/TileJSON） |

引擎侧状态语义（`admin/registry.rs`）：`off/stopped/paused` 的服务在 `refresh_catalog` 时被跳过，且 `retain_by` 从瓦片集/图层集中移除；恢复后重新打开。

### 9.9 健康检查

`POST /admin/services/{kind}/{name}/check`（`admin/check.rs`）对 PostGIS 图层执行：

- 连接池可用性；
- `SELECT count(*)` 或 `ST_Extent` 探测；
- 注册表状态；
- 结果汇总为 `report`。

**注意**：当前实现会把 `pg.dsn` 原样写入报告（`check.rs:354`），存在凭据泄漏风险（见 §12）。

---

## 10. 引擎运行时服务路径

### 10.1 MVT

入口：`handlers/mvt.rs`。

路由：

```
GET /mvt/{layer}/{z}/{x}/{y}
GET /mvt/{layer}/{tms}/{z}/{x}/{y}
```

分支（`mvt.rs:62`）：

```rust
if matches!(layer.def.source, SourceKind::Postgis(_)) {
    let (pool, def) = state.pg_registry()?.find(&layer_name)?;
    // 显式接口段校验：不可兑现的 CRS 一律 400，不静默回退
    if let Some(seg) = tms { validate_interface(...)?; }
    return serve_pg(...).await;
}
```

`serve_pg`（`mvt.rs:235`）处理三种情况：

| 请求 | 网格 | SQL |
|---|---|---|
| `tms` 为 `3857` / `EPSG:3857` / `WebMercatorQuad` | Web Mercator | `tile_sql` / `tile_sql_env` |
| `tms` 为源 SRID（如 `4543`）或自定义网格 id | `grid.rs` / `custom_grids` | `tile_sql_projected` / `tile_sql_projected_env` |
| 未指定 | 图层默认网格 | 按默认网格解析 |

关键机制：

1. **缓存键** `mvt-pg/{layer}/{grid}/{z}/{x}/{y}`，包含网格 id，避免同一 z/x/y 在不同接口下串包；
2. **空瓦片负缓存**：查询结果为空时缓存空字节，减少重复 SQL；
3. **singleflight**：`tile_flights` 合并并发同瓦片请求，避免缓存击穿；
4. **gzip**：冷路径压缩一次后缓存压缩结果；
5. **错误不缓存**：SQL 失败直接 5xx，不写缓存；
6. **行序**：`ST_AsMVT` 输出为二进制 pbf，`Content-Type: application/vnd.mapbox-vector-tile`。

`validate_interface`（`mvt.rs:685`）保证：显式 `tms` 段必须是该图层能兑现的接口（默认网格、源 SRID、`3857` 别名），否则 400。

### 10.2 TileJSON

`GET /mvt/{layer}/tilejson.json` / `.../{tms}/tilejson.json`（`mvt.rs:143`）。

输出包含：

- `tilejson: "3.0.0"`；
- `name` / `description`；
- `minzoom` / `maxzoom`（取配置）；
- `bounds`（启动探测的 4326 范围）；
- `center`；
- `tiles`（带 base URL 与网格段）；
- `vector_layers`：`id = layer_id_or(name)`，`fields` 来自 `properties`，`minzoom`/`maxzoom`；
- 自定义网格时输出对应 `scheme`/`tiles` 模板。

### 10.3 WMS

`handlers/wms.rs`：

- `GetMap`：`pg_get_map`（`wms.rs:299`）
  - bbox 先转 4326；
  - `limit = def.limit.unwrap_or(50_000)`（硬上限，防止全国范围 GetMap 拉全表）；
  - `feature_sql(def, Some(bbox_4326), None, None, limit, 0)`；
  - 查询结果转 FeatureCollection，交给与文件图层相同的矢量渲染器（SLD/默认样式）；
  - PNG 输出，`Cache-Control: public, max-age=3600`。
- `GetFeatureInfo`：`pg_feature_info`（`wms.rs:591`）
  - 点查询 `point_feature_sql`；
  - 返回 `text/plain`（或按 `INFO_FORMAT`）。

PostGIS 图层不参与栅格影像金字塔；`GetCapabilities` 仍按 WMS 1.1.1/1.3.0 输出图层元数据。

### 10.4 WFS

`handlers/wfs.rs`：

- `DescribeFeatureType`：从 `def.properties` 与几何列生成 GML schema（`wfs.rs:63`）；
- `GetFeature`：`pg_get_feature`（`wfs.rs:215`）
  - 支持 `BBOX`、`FILTER`（OGC Filter → WHERE）、`featureID`（按 `id_column`）；
  - 分页 `startIndex`/`count`；
  - `resultType=hits` 走 `count_sql`；
  - 输出 GML/GeoJSON（按 `outputFormat`）。

### 10.5 OGC API - Features

`handlers/ogcapi_features.rs`：

- `GET /ogc/features/v1/collections`：来自 `collections_of`（PostGIS 图层 + 文件图层）；
- `GET .../items`：
  - PostGIS 分支（`ogcapi_features.rs:154`）：
    - `filter=<xml>` → `filter_to_where`，**失败即 400**；
    - `sortby` → `parse_sortby`（白名单），**失败即 400**；
    - `bbox`/`limit`/`offset` 直接进 SQL；
    - `limit` 再被 `def.limit` 夹紧；
    - `numberMatched` 用 `count_sql` 服务端计数；
    - 下一页 `next` 链接按 `offset + returned` 生成。
  - 文件图层分支：内存 FeatureCollection + 文档缓存（`state.cache.doc`）。
- `GET .../items/{featureId}`：PostGIS 分支 `pg_item` 按 id SQL 查询；文件图层走 `state.cache.feature`。

> PostGIS 路径**不缓存**要素文档：数据库即缓存，避免旧 page cache 绕过实时查询。

### 10.6 其他协议

- WMTS：`/wmts` KVP、`/wmts/1.0.0/WMTSCapabilities.xml`、REST 路由；`TileMatrixSet` 由发布网格/自定义网格生成；瓦片通过 MVT 或矢量渲染返回（PostGIS 图层为动态查询，不是预切片）。
- OGC API - Tiles、TMS/XYZ：与 MVT 共用 `serve_pg` / 网格解析。
- 数据面鉴权：`server.data_token` 配置时，`X-Data-Token` / `Bearer` / `?token=` 三者之一必须匹配；未配置则不设防（向后兼容）。

---

## 11. 安全设计

| 面 | 措施 | 代码 |
|---|---|---|
| 标识符注入 | 所有 schema/table/column 走 `quote_ident` | `pg_source/sql.rs` |
| 字面量注入 | Filter 值全部 `$n` 参数化 | `pg_source/filter.rs` |
| `from` 注入 | 启动 `validate` 拒绝 `;`；管理员可信 | `pg_source_def.rs:119` |
| 排序注入 | `parse_sortby` 白名单 | `pg_source/sql.rs` |
| 导出注入 | `sortby`/`filter` 非法即 400，不静默 | `ogcapi_features.rs`、`wfs.rs` |
| 目录穿越 | 服务名 `sanitize_name`（禁止路径分隔符） | `admin/catalog_admin.rs` |
| 数据根约束 | 本地路径必须位于 `data_root` 内 | `admin/discover.rs` |
| 管理面鉴权 | `admin.token`（`X-Admin-Token`/Bearer） | `admin/http.rs` |
| DSN 回显 | manager 列表/详情只回掩码 | `catalog.rs:801`、`mapsvc.rs:944` |
| 连接测试 | 临时池 size=1，不落盘 | `admin/catalog_admin.rs:252` |
| 发现只读 | `geometry_columns` + `ST_Extent`，不读业务行 | `admin/discover.rs:293` |
| 导入重名 | 目标表存在返回 409 | `admin/pg_import.rs` |
| 单请求上限 | `limit` 进 SQL；WMS 默认 50k；pg_query ≤1000 | `sql.rs`、`wms.rs:299`、`catalog_admin.rs:298` |

---

## 12. 已知限制与风险清单

以下为代码审阅中发现、值得在上线前决策的事项。

### 12.1 健康检查报告泄漏完整 DSN（高风险）

`mapserver/services/map-api/src/admin/check.rs:354` 把 `pg.dsn`（含密码）原样放进检查报告。manager 会把报告透传给前端/日志。建议改为 `mask_conn` 或只输出 `host:port/db`。

### 12.2 `db` catalog 后端与 manager 发布流程不一致（高风险）

- `db_catalog::load_catalog` 只读 `sys_published_layer.service_doc`；
- 但 manager 的 `record_published`（`catalog.rs:2324`）**不写 `service_doc`**；
- 当前唯一写入方是 `map-api catalog-import` CLI。

因此若把引擎切到 `catalog.backend = "db"`，通过 manager 发布的图层**不会**在引擎重启后被加载。当前默认 `files` 后端不触发。建议二选一：manager 发布时同步生成 `service_doc`，或在文档/配置中明确 `db` 模式必须配合 `catalog-import`。

### 12.3 不使用 TLS

`pool.rs` 固定 `NoTls`。跨网段连接需依赖网络隔离或外部隧道（如 stunnel/pgBouncer TLS）。若目标环境要求 TLS，需要引入 `tokio-postgres-rustls` 并为 `Manager` 配置 connector。

### 12.4 DSN 明文存储

- `sys_store.pg_dsn` 明文；
- 发布 XML / 请求体中也含明文 DSN；
- 建议数据库层加密或使用环境变量引用（当前 `xmlcfg` 支持 `${ENV}` 展开，但 manager 写入的是字面量）。

### 12.5 `from` 是管理员可信 SQL

`from` 仅拒绝 `;`，不能防住任意表达式（如子查询内的函数调用）。有 admin 权限的人本就能写配置，风险可接受；但应确保 `admin.token` 不被低权限用户获取。

### 12.6 发现阶段 `ST_Extent` 成本

每张空间表执行一次全表 `ST_Extent`，大表/多表时发现明显变慢。可考虑：优先 `ST_EstimatedExtent`、按需点击探测、或后台缓存。

### 12.7 覆盖/删除语义

- 引擎 `POST /admin/services` 对同名服务是**覆盖写**；
- manager 用 `ensure_name_free` 防止覆盖在线同名服务；
- 但直接调用引擎管理面（有 token）仍可覆盖，需以 token 管理作为边界。

### 12.8 PostGIS 图层不提供 WMTS/XYZ 预切片

所有瓦片都是动态 SQL 查询。高并发下依赖连接池（每 DSN 8 连接）与 GiST 索引；如需静态切片，需要额外的切片流水线。

### 12.9 默认端口 54321

manager 预检默认 `54321`（项目约定），与 PostgreSQL 常见默认 5432 不同；用户需按实际端口填写，否则报连接失败。

### 12.10 每图层注册表复用判断较粗

热重载只判断「现有池是否覆盖所有仍在服役的图层」，不比较 DSN 是否变化；若同名图层 DSN 被编辑，可能需要重启才能生效。发布/修改流程中建议显式提示。

---

## 13. 常见错误与排障

| 现象 | 可能原因 | 排查 |
|---|---|---|
| 启动失败 `postgis layer 'x': ...` | `from` 为空/含 `;`、`table` 与 `from` 都缺失、`tile_units` 非法 | 看启动日志中的图层名，改 XML |
| `PostgisTooOld` | PostGIS < 3.0 | `SELECT postgis_full_version();`，升级 |
| 瓦片空白但 SQL 有结果 | SRID 配错 / 网格选错 | 检查 `srid` 与表一致；用 `/mvt/{layer}/3857/...` 与源 SRID 接口对比 |
| `no pool (registry disabled?)` | 没有 PostGIS 图层或注册表未构建 | 检查配置是否含 `source.type: postgis`；重启/重载 |
| `tile {z}/{x}/{y} out of range` | 网格层级/索引越界 | 检查 `tms` 与 z/x/y |
| 400 `invalid filter` / `invalid sortby` | Filter 算子不支持 / 排序列不在白名单 | 用 `properties` 内的列；查看错误详情 |
| `publish 未生效：...` | 引擎 `served=false`，看 `skip_reason` | 通常是表/SRID/属性发现失败或服务被停用 |
| `服务名已存在且在线` | 同名台账未删除 | 修改发布信息或先删除/停用旧服务 |
| SHP 导入 409 | 目标表已存在 | 换表名或先删表 |
| 导入后看不到表 | 未重新发现 | 调 `/discover` 或刷新资源 |
| 连接超时 | 端口/防火墙/`listen_addresses`/`pg_hba.conf` | 先用 `psql` 验证；确认端口（默认可能不是 5432） |
| 中文乱码 | DBF 编码未指定/错误 | 导入时显式传 `encoding`（如 `GBK`、`UTF-8`） |

---

## 14. 代码索引

### 14.1 核心库 `gisserver`

| 路径 | 内容 |
|---|---|
| `gisserver/src/pg_source/mod.rs` | `PgRegistry`：共享池、`find`/`iter`/`len` |
| `gisserver/src/pg_source/pool.rs` | `PgPool`、版本预检、`new_plain` |
| `gisserver/src/pg_source/sql.rs` | 全部 SQL 模板与 `query_*`、`parse_sortby`、单测 |
| `gisserver/src/pg_source/filter.rs` | OGC Filter → WHERE、GML 几何 |
| `gisserver/src/pg_source/grid.rs` | 源 SRID 网格 |
| `gisserver/src/wms_common/pg_source_def.rs` | `PgSourceDef` / `SimplifyOpts` / `validate` |
| `gisserver/src/wms_common/layer.rs` | `SourceKind::Postgis(PgSourceDef)` |

### 14.2 引擎 `mapserver/services/map-api`

| 路径 | 内容 |
|---|---|
| `src/state.rs` | `build_pg_registry`（139）、`pg_registry()`（637）、`refresh_catalog` |
| `src/main.rs` | 启动时构建注册表（215）、db catalog 加载 |
| `src/config.rs` | `CatalogOpts`、`collect_layers` |
| `src/db_catalog.rs` | 从 `service_doc` 载入图层 |
| `src/catalog_import.rs` | XML → `service_doc` 导入 CLI |
| `src/layer.rs` | PostGIS 图层打开（不建池）、`is_postgis` |
| `src/handlers/mvt.rs` | PostGIS 动态瓦片、TileJSON、缓存/singleflight |
| `src/handlers/wms.rs` | `pg_get_map`、`pg_feature_info` |
| `src/handlers/wfs.rs` | DescribeFeatureType、`pg_get_feature` |
| `src/handlers/ogcapi_features.rs` | items/item、filter、sortby |
| `src/admin/catalog_admin.rs` | `/admin/services`、`pg-test`、`pg-query` |
| `src/admin/discover.rs` | `/admin/pg-tables`、能力矩阵、data_root 约束 |
| `src/admin/pg_import.rs` | SHP 导入 + SSE |
| `src/admin/check.rs` | 健康检查（注意 DSN 泄漏，§12.1） |
| `src/admin/http.rs` | 管理面服务列表/状态/重载 |
| `src/handlers/mod.rs` | 数据面/管理面路由表 |

### 14.3 管理端 `manager`

| 路径 | 内容 |
|---|---|
| `backend/src/handlers/catalog.rs` | Store/资源/发布/生命周期全部流程 |
| `backend/src/handlers/mapsvc.rs` | `mask_conn` DSN 掩码 |
| `backend/sql/map.sql` | `sys_store` / `sys_resource` / `sys_published_layer` |
| `ui/src/views/map/catalog/store.vue` | PostGIS Store 表单、连接测试 |
| `ui/src/views/map/catalog/resource.vue` | 发现、资源列表 |
| `ui/src/views/map/catalog/ImportShpDialog.vue` | SHP 导入对话框 |
| `ui/src/views/map/catalog/PublishDialog.vue` | 发布对话框 |

### 14.4 配置样例

| 路径 | 内容 |
|---|---|
| `run-env/config/postgis/wuhua_buildings.xml` | EPSG:4543 + 自定义网格 |
| `run-env/config/postgis/countries.xml` | EPSG:4326 示例 |
| `manager/deploy/config/mapserver/mapserver.xml` | catalog 后端配置说明 |

---

## 15. 附录：请求示例与 SQL 速查

### 15.1 管理器 → 引擎

```http
POST /admin/pg-test
Content-Type: application/json
X-Admin-Token: ***

{"dsn":"postgres://postgres:***@localhost:54321/gis"}
```

```http
POST /admin/pg-tables
Content-Type: application/json
X-Admin-Token: ***

{"dsn":"postgres://postgres:***@localhost:54321/gis","schema":"public"}
```

```http
POST /admin/services
Content-Type: application/json
X-Admin-Token: ***

{
  "kind":"postgis",
  "name":"wuhua_buildings",
  "title":"五华区建筑",
  "src_crs":"EPSG:4543",
  "extent":[102.6,25.0,102.7,25.1],
  "source":{
    "type":"postgis",
    "dsn":"postgres://postgres:***@localhost:54321/gis",
    "schema":"public",
    "table":"wuhua_buildings",
    "geometry_column":"geom",
    "srid":4543
  },
  "grids":["WebMercatorQuad","CGCS2000_3dCM102E"]
}
```

### 15.2 运行时

```http
GET /mvt/wuhua_buildings/14/13218/6789
GET /mvt/wuhua_buildings/4543/14/13218/6789
GET /mvt/wuhua_buildings/tilejson.json
GET /wms?SERVICE=WMS&REQUEST=GetMap&LAYERS=wuhua_buildings&...
GET /wfs?SERVICE=WFS&REQUEST=GetFeature&TYPENAMES=wuhua_buildings&...
GET /ogc/features/v1/collections/wuhua_buildings/items?limit=100&bbox=102.6,25.0,102.7,25.1
GET /ogc/features/v1/collections/wuhua_buildings/items?filter=<Filter>...</Filter>&sortby=-height
```

### 15.3 SQL 速查

```sql
-- 版本
SELECT version(), postgis_full_version();

-- 空间表
SELECT f_table_schema, f_table_name, f_geometry_column, srid, type
FROM geometry_columns
WHERE f_table_schema = 'public';

-- 范围（快）
SELECT ST_EstimatedExtent('public','wuhua_buildings','geom');

-- 范围（精确）
SELECT ST_Extent(geom) FROM public.wuhua_buildings;

-- 索引检查
SELECT count(*) FROM pg_index i
JOIN pg_class c ON c.oid = i.indrelid
JOIN pg_attribute a ON a.attrelid = c.oid AND a.attnum = ANY(i.indkey)
WHERE c.relname = 'wuhua_buildings'
  AND a.attname = 'geom'
  AND i.indisvalid
  AND i.indpred IS NULL;

-- 补 GiST 索引
CREATE INDEX ON public.wuhua_buildings USING GIST (geom);
```

### 15.4 构建

```bat
build\script\build_all.bat
```

该脚本设置共享 `CARGO_TARGET_DIR=<repo>/build/target`，先构建 `mapserver`，再构建 manager 后端（可追加 `frontend` 参数构建前端）。

---

## 结语

PostGIS 数据源在本项目中是**配置驱动、可选启用**的动态数据面：管理端负责把「连接 → 表 → 发布」变成台账与引擎配置，引擎在启动/热重载时一次性完成校验、属性发现、索引检查、范围与计数探测，并按 DSN 共享连接池；运行时所有瓦片与要素都由参数化 SQL 实时生成，配合 GiST 索引、单请求上限、网格感知缓存与 singleflight 保证可用性。

上线前建议优先处理 §12.1（DSN 泄漏）与 §12.2（db 后端发布一致性），并根据部署网络决定是否引入 TLS。
