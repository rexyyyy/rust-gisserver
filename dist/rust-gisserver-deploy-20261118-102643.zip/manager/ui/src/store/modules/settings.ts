import { defineStore } from 'pinia';
import defaultSettings from '@/settings';
import { useDynamicTitle } from '@/utils/dynamicTitle';
import { useStorage } from '@vueuse/core';
import { ref } from 'vue';
import { NavTypeEnum } from '@/enums/NavTypeEnum';

export const useSettingsStore = defineStore('setting', () => {
  const storageSetting = useStorage<LayoutSetting>(
    'layout-setting',
    {
      tagsView: defaultSettings.tagsView,
      tagsIcon: defaultSettings.tagsIcon,
      fixedHeader: defaultSettings.fixedHeader,
      sidebarLogo: defaultSettings.sidebarLogo,
      dynamicTitle: defaultSettings.dynamicTitle,
      sideTheme: defaultSettings.sideTheme,
      theme: defaultSettings.theme,
      navType: defaultSettings.navType,
      radiusBase: defaultSettings.radiusBase
    },
    undefined,
    {
      // 合并默认值：useStorage 默认不合并，localStorage 里的旧对象缺新字段时会取不到默认值
      mergeDefaults: true
    }
  );
  const title = ref<string>(defaultSettings.title);
  const theme = ref<string>(storageSetting.value.theme);
  const sideTheme = ref<string>(storageSetting.value.sideTheme);
  const showSettings = ref<boolean>(defaultSettings.showSettings);
  const tagsView = ref<boolean>(storageSetting.value.tagsView);
  const tagsIcon = ref<boolean>(storageSetting.value.tagsIcon);
  const fixedHeader = ref<boolean>(storageSetting.value.fixedHeader);
  const sidebarLogo = ref<boolean>(storageSetting.value.sidebarLogo);
  const dynamicTitle = ref<boolean>(storageSetting.value.dynamicTitle);
  const animationEnable = ref<boolean>(defaultSettings.animationEnable);
  const dark = ref<boolean>(defaultSettings.dark);
  const navType = ref<NavTypeEnum>(storageSetting.value.navType || NavTypeEnum.LEFT);
  const radiusBase = ref<number>(storageSetting.value.radiusBase ?? defaultSettings.radiusBase);

  const setTitle = (value: string) => {
    title.value = value;
    useDynamicTitle();
  };
  return {
    storageSetting,
    title,
    theme,
    sideTheme,
    showSettings,
    tagsView,
    tagsIcon,
    fixedHeader,
    sidebarLogo,
    dynamicTitle,
    animationEnable,
    dark,
    navType,
    radiusBase,
    setTitle
  };
});
