# rust-gisserver 部署包（源码 bundle）

本包是 **源码 + 编排配置** 的部署包：两台机器的镜像都在目标机现场构建
（仓库未推镜像仓库），因此目标机需要 Docker Desktop（Linux 容器模式）+
可访问外网（拉 Rust crates、npm 包、PostGIS 镜像）。

## 1. 解压

    unzip rust-gisserver-deploy-*.zip -d <目标目录>

解压后得到一个含 `gisserver/`、`mapserver/`、`manager/` 的仓库根目录。
**目录层级必须保持原样** —— mapserver 的核心库是 path 依赖 `../gisserver`，
且 compose 的 build context 依赖相对路径（`../../..` = 仓库根，`../..` = manager/）。

## 2. 选平台目录

    manager/deploy_zh-cn/win/     中文 + Windows
    manager/deploy_zh-cn/linux/   中文 + Linux
    manager/deploy_en/win/        英文 + Windows
    manager/deploy_en/linux/      英文 + Linux

Windows 用 `win/`，Linux 用 `linux/`；中文用 `deploy_zh-cn`，英文用 `deploy_en`。
四个目录是独立 compose 项目（卷互不共享），端口相同不能同时起。

## 3. 配置 .env

    cd manager/deploy_zh-cn/linux        # 按实际平台/语言替换
    cp ../../deploy/.env.example .env

至少改 `MANAGER_JWT_SECRET`（必填，compose 用 `:?` 强校验）；共享环境务必把
`MAPSERVER_DB_PASSWORD` 改成强口令。Windows 用 `copy` 代替 `cp`。

## 4. 启动

Linux：

    bash ../../deploy/start.sh --dir .

Windows：

    pwsh -File ..\..\deploy\start.ps1 -Dir .

脚本会：读 .env → docker compose up -d --build → 等 PostGIS healthy → 自动自检。
也可手动：

    docker compose up -d --build

首次构建要现场编译 Rust 与前端，视网络与机器性能约 10~30 分钟。

## 5. 验收

    前端    : http://localhost:6180/
    map-api : http://localhost:8080/health
    WMS     : http://localhost:8080/wms?service=WMS&request=GetCapabilities

`/health` 返回里应有 `"proj":true`：

    {"status":"ok","proj":true,"mode":"standalone","manager":null}

`proj:true` 表示 PROJ 投影后端已加载 —— 跨 CRS 重投影（EPSG:4490 / 高斯-克吕格
45xx / UTM）可用。`proj:false` 不影响服务启动，但上述跨 CRS 请求会失败，此时查：

    docker compose logs map-api | grep -i proj

自检（任一 FAIL 退出码 1）：

    bash ../../deploy/validate.sh --dir . --check-data-root

自检输出里的 `PROJ 后端` 一行即 PROJ 状态（PASS / WARN）。

## 常见问题

- **构建慢/超时**：首次拉 crates + npm 包。若目标机在墙内，构建已默认走 USTC
  rustup 源；npm 源可在 `manager/ui/.npmrc` 追加镜像。
- **Cargo.lock 依赖**：包内已带 `gisserver/Cargo.lock` 与 `mapserver/Cargo.lock`，
  版本已固定，离线构建仍需 crates 源可达。
- **端口被占**：改 `.env` 的 `MAPSERVER_DB_PORT`（DB）、`GISDATA_DIR`（数据挂载点）。
- **英文库显示中文菜单**：英文库种子只影响 DB 文本，中文请求下会显示英文
  （中间件无 en→zh 路径），属预期。
